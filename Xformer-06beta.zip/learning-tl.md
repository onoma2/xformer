# Teletype Track Learning Tutorial for Performer

## Teletype Track Setup (I/O Mapping)

If your Teletype track is new, set up its I/O first so scripts can see the correct inputs/outputs.

1. **Select the Teletype track**  
   Press the Track button for the track slot where Teletype is loaded.

2. **Open the Track page (I/O list)**  
   Press **Page + Track** to open the track list model for the selected track.

3. **Map Teletype inputs**  
   - **TI-TR1..TI-TR4**: assign trigger sources (CV inputs or gate outputs).  
   - **TI-IN**: select the CV source for `IN`.  
   - **TI-PARAM**: select the CV source for `PARAM`.  
   - **Note**: CV inputs here are direct hardware inputs (no routing needed).

4. **Map Teletype outputs**  
   - **TO-TRA..TO-TRD**: map Teletype trigger outputs A–D to Performer gate outputs.  
   - **TO-CV1..TO-CV4**: map Teletype CV outputs 1–4 to Performer CV outputs.
   - **Tip**: Make sure the corresponding gate/CV outputs are enabled in the **Layout** page.

5. **(Optional) Adjust ranges/offsets**  
   - **CV1 RNG/OFF .. CV4 RNG/OFF**: set per-output voltage range and offset.

After this, proceed to Script View and start editing scripts.

## BUS Routing Example (Performer)

BUS is a shared CV bus (3 slots) that lets Teletype modulate other tracks without using hardware CV outputs.

Example: Teletype drives NoteTrack transpose via BUS 1.

1. In Teletype Script View (LIVE or S0), set BUS 1:
```
BUS 1 X
```
2. In the Routing page, create a route:
   - **Source**: BUS 1
   - **Target**: Transpose (or any track target)
   - **Tracks**: select the target track(s)
3. Now changing X in Teletype updates BUS 1 and modulates the route target.

Note: BUS is global. Multiple Teletype tracks can read/write the same BUS slot directly without routing.

## Performer Teletype Keyboard Shortcuts

The Performer implementation of Teletype includes specific keyboard shortcuts for editing scripts:

### Function Keys (F0-F4)
- **F0**: Toggle LIVE ↔ S0
- **F1**: Select S1
- **F2**: Select S2
- **F3**: Toggle S3 ↔ Metro
- **F4**: Toggle Pattern View
- **Shift + F0-F3**: Fire script S0-S3 (TI-TR1..4)

### Step Keys (Steps 1-16)
- **Steps 1-16**: Insert common teletype commands/variables (cycles through options)
  - **Step 1**: 1 → A → B (cycles through 1→A→B)
  - **Step 2**: 2 → C → D (cycles through 2→C→D)
  - **Step 3**: 3 → E → F (cycles through 3→E→F)
  - **Step 4**: 4 → G → H (cycles through 4→G→H)
  - **Step 5**: 5 → I → J (cycles through 5→I→J)
  - **Step 6**: 6 → K → L (cycles through 6→K→L)
  - **Step 7**: 7 → M → N (cycles through 7→M→N)
  - **Step 8**: 8 → O → P (cycles through 8→O→P)
  - **Step 9**: 9 → Q → R (cycles through 9→Q→R)
  - **Step 10**: 0 → S → T (cycles through 0→S→T)
  - **Step 11**: . → U → V (cycles through .→U→V)
  - **Step 12**: : → W → X (cycles through :→W→X)
  - **Step 13**: ; → Y → Z (cycles through ;→Y→Z)
  - **Step 14**: CV → CV.SLEW → RRAND
  - **Step 15**: TR.P → PARAM → ELIF
  - **Step 16**: M.ACT → P.NEXT → BUS


### Page + Step Keys (Steps 1-16)
- **Page + Step 9**: Copy current line
- **Page + Step 10**: Paste line
- **Page + Step 11**: Duplicate line
- **Page + Step 12**: Comment/uncomment line
- **Page + Step 13**: Delete line

### Shift + Step Keys (Steps 1-16)
- **Shift + Steps 1-16**: Insert special characters
  - **Shift + Step 1**: + (Plus)
  - **Shift + Step 2**: - (Minus)
  - **Shift + Step 3**: * (Multiply)
  - **Shift + Step 4**: / (Divide)
  - **Shift + Step 5**: % (Modulo)
  - **Shift + Step 6**: = (Equals)
  - **Shift + Step 7**: < (Less than)
  - **Shift + Step 8**: > (Greater than)
  - **Shift + Step 9**: ! (Logical NOT)
  - **Shift + Step 10**: & (Bitwise AND)
  - **Shift + Step 11**: | (Bitwise OR)
  - **Shift + Step 12**: ^ (Bitwise XOR)
  - **Shift + Step 13**: $ (Dollar sign)
  - **Shift + Step 14**: @ (At symbol)
  - **Shift + Step 15**: ? (Question mark)
  - **Shift + Step 16**: ; (Semicolon)

### Navigation and Editing
- **Left Arrow**: Backspace (delete character to the left)
- **Shift + Left Arrow**: Move cursor left
- **Right Arrow**: Insert space
- **Shift + Right Arrow**: Move cursor right
- **Encoder Press**: Load selected line into edit buffer
- **Shift + Encoder Press**: Commit line (save changes)
- **Encoder Turn**: Move cursor left/right (normal) or select line (with Shift)

### Other Controls
- **Page + Left/Right**: History prev/next (live/edit)

## Teletype Pattern View Keyboard Shortcuts

The Performer implementation also includes a pattern view for editing teletype patterns:

### Function Keys
- **F0-F3**: Select pattern 0-3
- **F4**: Toggle back to Script View

### Step Keys (Steps 1-16)
- **Steps 1-9**: Insert digits 1-9 into the currently selected pattern position
- **Step 10 (0)**: Insert digit 0 into the currently selected pattern position
- **Step 14**: Set pattern length to current row position
- **Step 15**: Set pattern start position to current row
- **Step 16**: Set pattern end position to current row

### Navigation and Editing
- **Left Arrow**: Backspace digit (while editing); **Shift + Left** deletes row
- **Right Arrow**: Insert row; **Shift + Right** toggles turtle display
- **Encoder Turn**: Move up/down through pattern rows
- **Encoder Press**: Negate current value (make positive/negative)
- **Shift + Encoder Press**: Commit edited value

## Introduction

This tutorial is designed for intermediate teletype users who want to learn how to use the Teletype Track functionality within the Performer firmware. The Teletype Track in Performer provides a powerful way to integrate teletype scripts with your sequencer, allowing for complex musical patterns and interactions.

## Prerequisites

Before starting this tutorial, you should have:
- Basic understanding of teletype operations and syntax
- Familiarity with the Performer sequencer interface
- Understanding of CV/Gate concepts in modular synthesis

## Overview of Teletype in Performer

The Teletype Track in Performer provides:
- 4 CV outputs (CV 1-4) mapped to Performer's CV outputs
- 4 Gate outputs (TR A-D) mapped to Performer's gate outputs
- 4 trigger inputs (TI-TR1-4) to trigger scripts
- 2 CV inputs (TI-IN and TI-PARAM) from Performer's CV inputs
- Integration with Performer's clock system
- Pattern and variable storage

## Section 1: Basic Script Setup

### Step 1: Creating Your First Script

Let's start with a simple script that toggles a gate output when triggered:

```
TR.TOG A
```

This script will toggle gate output A each time the trigger input receives a signal.

### Step 2: Adding CV Output

Now let's add a CV output to the script:

```
TR.TOG A
CV 1 V 5
```

This will toggle gate A and set CV 1 to 5 volts when triggered.

### Step 3: Using Variables

Let's make the CV voltage dynamic using variables:

```
X ADD X 1
CV 1 V X
TR.TOG A
```

This script increments variable X each time it's triggered, sets CV 1 to that voltage, and toggles gate A.

## Section 2: Working with Patterns

### Step 4: Basic Pattern Usage

Patterns allow you to create sequences of values. Let's create a simple melody pattern:

```
CV 1 N P.NEXT
```

This script sets CV 1 to the next note in the pattern each time it's triggered.

### Step 5: Loading Pattern Values

To load values into the pattern, you can use the following commands in LIVE mode:

```
P.PUSH 0
P.PUSH 12
P.PUSH 7
P.PUSH 5
P.L 4
```

This creates a 4-step pattern with semitone values (0, 12, 7, 5) representing a simple chord progression.

### Step 6: Multiple Patterns

You can use multiple pattern banks (0-3):

```
P.N 1        // Switch to pattern 1
P.PUSH 0
P.PUSH 2
P.PUSH 4
P.PUSH 5
P.L 4
```

Then in your script:

```
CV 1 N PN.NEXT 1    // Get next value from pattern 1
```

## Section 3: Advanced Control Flow

### Step 7: Using EVERY for Clock Division

```
EVERY 2: TR.P A      // Pulse gate A every 2 triggers
EVERY 4: TR.P B      // Pulse gate B every 4 triggers
CV 1 V RAND 5        // Set CV 1 to random voltage 0-5V
```

### Step 8: Conditional Logic with IF

```
IF GT X 5: CV 1 V 5
IF LTE X 5: CV 1 V 0
X ADD X 1
TR.TOG A
```

This script checks if X is greater than 5, sets CV 1 accordingly, increments X, and toggles gate A.

### Step 9: Loops with L

```
L 1 4: TR.P I        // Pulse gates 1-4 in sequence
CV 1 N RAND 24       // Random note in 2-octave range
```

## Section 4: Integration with Performer Clock

### Step 10: Clock-Based Timing

In Performer, you can set the Teletype track to use clock timing instead of ms timing:

```
M.ACT 1              // Enable metronome
M 500                // Set metronome to 500ms (120 BPM)
```

### Step 11: Using Metro Script

The metro script runs at the metronome interval:

```
// In M script:
CV 2 V DRUNK         // Set CV 2 to drunk-walk voltage
DRUNK.WRAP 1         // Enable wrapping
```

## Section 5: CV Inputs and Parameter Control

### Step 12: Using CV Inputs

You can use the IN and PARAM variables to read from CV inputs:

```
CV 1 V IN            // Set CV 1 to value of IN input
CV 2 V PARAM         // Set CV 2 to value of PARAM input
```

### Step 13: Scaling CV Inputs

```
X SCALE 0 16383 0 10 IN    // Scale IN from 0-16383 to 0-10V
CV 1 V X
```

## Section 6: Advanced Pattern Operations

### Step 14: Pattern Manipulation

```
P.NEXT              // Get next value in pattern
P.I ADD P.I 2       // Skip 2 steps in pattern
CV 1 N P.HERE       // Set CV to current pattern value
```

### Step 15: Pattern Ranges

```
P.START 2           // Set pattern start to index 2
P.END 6             // Set pattern end to index 6
P.WRAP 1            // Enable wrapping within range
```

## Section 7: Randomness and Probability

### Step 16: Random Operations

```
PROB 50: TR.P A      // 50% chance to pulse gate A
CV 1 V RRAND 2 8    // Random voltage between 2 and 8V
```

### Step 17: Drunk Walk

```
CV 1 V DRUNK         // Use drunk walk for CV
DRUNK.MIN 0          // Set minimum value
DRUNK.MAX 16383      // Set maximum value
DRUNK.WRAP 0         // Don't wrap at boundaries
```

## Section 8: MIDI Integration

### Step 18: MIDI Operations (Performer-specific)

```
MI.NV                // Get latest MIDI note as voltage
MI.CCV               // Get latest MIDI CC as voltage
CV 1 V MI.LNV        // Set CV 1 to latest MIDI note voltage
```

## Section 9: Delay and Stack Operations

### Step 19: Using Delays

```
TR.P A
DEL 100: TR.P B     // Trigger B 100ms after A
DEL 200: TR.P C     // Trigger C 200ms after A
```

### Step 20: Using Stacks

```
S: CV 1 V 5         // Stack this command
S: TR.P A           // Stack this command
S.ALL               // Execute all stacked commands
```

## Section 10: Complex Example

### Step 21: Complete Pattern Sequencer

Here's a complete example that combines multiple concepts:

```
// Script 1 (triggered by input):
CV 1 N P.NEXT        // Next note in main pattern
TR.P A               // Pulse gate A
X ADD X 1            // Increment step counter
MOD X 8              // Wrap at 8 steps
EQ X 0               // Check if at step 0
PROB 75: SCRIPT 2    // 75% chance to run script 2 on step 0

// Script 2 (called conditionally):
CV 2 V RAND 10       // Random CV on output 2
TR.P B               // Pulse gate B
```

## Section 11: Troubleshooting and Tips

### Common Issues:

1. **Scripts not running**: Check trigger input mapping in the UI
2. **CV outputs not working**: Verify CV output mapping in the UI
3. **Pattern not advancing**: Make sure you're using P.NEXT or manually incrementing P.I

### Performance Tips:

1. **Keep scripts efficient**: Complex scripts can impact performance
2. **Use appropriate timing**: Use clock timing for synced sequences
3. **Organize patterns**: Use different pattern banks for different purposes

## Section 12: Advanced Techniques

### Step 22: Function Scripts

Use SCRIPT to call other scripts as functions:

```
// Script 1: Main logic
CV 1 V RAND 5
SCRIPT 3             // Call script 3

// Script 3: Function
CV 2 V ADD CV 2 1    // Increment CV 2
```

### Step 23: Queue Operations

Use queues for smoothing or averaging:

```
Q CV 1               // Add current CV 1 value to queue
Q.N 4                // Set queue length to 4
CV 2 V Q.AVG         // Set CV 2 to average of queue
```

## Example Scripts from Teletype Codex

Here are some practical example scripts from the Teletype Codex that demonstrate advanced techniques:

### Example 1: Tetra Sequencer
This script creates 4 independent CV and trigger sequencers:

```
#1 (Main sequencer)
SCRIPT 2; SCRIPT 3; SCRIPT 4

#2 (Sequencer 1 & 2)
P.N 0; A P.HERE
IF NZ A: TR.P 1; CV 1 N A
P.NEXT
P.N 1; B P.HERE
IF NZ B: TR.P 2; CV 2 N B
P.NEXT

#3 (Sequencer 3 & 4)
P.N 2; C P.HERE
IF NZ C: TR.P 3; CV 3 N C
P.NEXT
P.N 3; D P.HERE
IF NZ D: TR.P 4; CV 4 N D
P.NEXT

#4 (Parameter control)
Y DIV PARAM 2
IF NZ PARAM: P.HERE Y

#5-8 (Randomize sequencers)
#5: P.N 0; P.INS 0 RRAND 0 1; PN.POP 0
#6: P.N 1; P.INS 0 RRAND 0 200; PN.POP 1
#7: P.N 2; P.INS 0 RRAND 0 200; PN.POP 2
#8: P.N 3; P.INS 0 RRAND 1 200; PN.POP 3

#I (Init script)
P.N 0; P.START 0; P.END 16
P.N 1; P.START 0; P.END 16
P.N 2; P.START 0; P.END 16
P.N 3; P.START 0; P.END 16
PN.I 0 0; PN.I 1 0; PN.I 2 0; PN.I 3 0
```

**What it does:** This creates a 4-channel sequencer where each pattern bank (0-3) controls a different CV and trigger output. When triggered, it advances all 4 patterns simultaneously, sending CV values to outputs 1-4 and triggering gates when the pattern value is non-zero.

**What to expect:** You'll get 4 synchronized sequencers that can play different patterns. Pattern 0 controls CV 1 and TR A, Pattern 1 controls CV 2 and TR B, and so on. The randomize scripts (5-8) will add random values to each pattern.

### Example 2: Turing Machine
A generative sequencer using probability:

```
#5 (Copy pattern 0 to 1)
L 0 7 : PN 1 I PN 0 I

#6 (Clock out pattern 1)
P.N 1
P.INS 0 P.POP
X 0
L 0 4 : X ADD X LSH P I I
CV 2 N PN 4 X
TR.PULSE 2

#7 (Parameter control)
P.N 0
I SCALE 100 16000 0 100 PARAM
PROB I : P.PUSH EZ P.POP

#8 (Clock trigger)
P.N 0
P.INS 0 P.POP
X 0
L 0 4 : X ADD X LSH P I I
CV 1 N PN 4 X
TR.PULSE 1

#I (Init script)
P.N 0
L 0 63 : P.POP
L 0 7 : P.PUSH TOSS
P.N 1
L 0 63 : P.POP
L 0 7 : P.PUSH PN 0 I
```

**What it does:** This creates a Turing machine-style generative sequencer that uses probability to determine whether to add new values to the pattern. It uses the PARAM knob to control the probability of adding new values.

**What to expect:** The sequencer will generate evolving patterns based on probability. When you press script 8, it will clock out a value from pattern 0 and send it to CV 1. Script 7 uses the PARAM knob to control the probability of adding new values to the pattern. The higher the PARAM value, the more likely it is to add new values.

### Example 3: Triangle Mountain
A melodic sequencer with scale control:

```
#1 (Reset position)
P.I 0

#2 (Next scale)
P.N WRAP ADD P.N 1 0 3
P.I P.END

#3 (Shorten loop)
P.END WRAP SUB P.END 1 1 7

#4 (Toggle forward/reverse)
X EZ X

#5 (Throw CV 2 a new note)
S : CV 2 ADD N P.HERE V 1
S : TR.PULSE B

#6 (Randomize loop length)
P.END RRAND 1 7

#7 (Set root to CV in)
Z IN

#8 (Add 1 semi to CV 4)
CV 4 N WRAP 0 0 11

#M (Metro script)
IF X : P.PREV
ELSE : P.NEXT
CV 1 ADD N P.HERE Z
M SUB 320 RSH PARAM 6
S.ALL
TR.PULSE A

#I (Init script)
L A B : TR.TIME I 40
```

**What it does:** This creates a melodic sequencer that can play forward or backward through a pattern, with tempo controlled by the PARAM knob. It allows transposition via CV input and can play in different scales.

**What to expect:** The sequencer will play through your pattern at a tempo set by the PARAM knob (higher PARAM = faster). Script 1 resets the position to 0, script 2 cycles through different pattern banks, script 3 shortens the loop, script 4 toggles between forward and reverse playback, script 5 sends a new note to CV 2, script 6 randomizes the loop length, script 7 sets the root note based on CV input, and script 8 adds 1 semitone to CV 4. The metro script runs automatically and sends the current pattern value to CV 1, transposed by the root note.

## Conclusion

This tutorial has covered the fundamental concepts of using Teletype in the Performer firmware. From basic scripts to complex pattern operations, you now have the tools to create intricate musical sequences and interactions.

Remember to experiment with different combinations of operations, and don't hesitate to refer back to the teletype manual for more detailed information about specific operations.

The key to mastering Teletype in Performer is practice and experimentation. Try modifying the examples in this tutorial to create your own unique patterns and behaviors.
## Hardware Mapping Summary (Reference)

### 1. TeletypeScriptViewPage (The Editor)

| Action | Hardware Control | Performer Function |
| :--- | :--- | :--- |
| **Select Line** | **Shift + Encoder Turn** | Moves the vertical selection (Lines 1-6). |
| **Edit Line** | **Encoder Press** | Loads selected line into the edit buffer. |
| **Commit Line** | **Shift + Encoder Press** | Compiles buffer and saves it to the script. |
| **Select Script** | **Fn 1 - Fn 9** | Switches between Scripts (S1-S8, Metro). |
| **Move Cursor** | **Encoder Turn** | Moves edit cursor horizontally. |
| **Cursor Left** | **Shift + Page Left** | Moves cursor left in edit buffer. |
| **Cursor Right** | **Shift + Page Right** | Moves cursor right in edit buffer. |
| **Backspace** | **Page Left** | Deletes character before cursor. |
| **Space** | **Page Right** | Inserts a space. |
| **Insert Text** | **Step Keys 1-16** | Cycles through characters (0-9, A-Z, symbols). |

### 2. TeletypePatternViewPage (The Tracker)

| Action | Hardware Control | Performer Function |
| :--- | :--- | :--- |
| **Select Row** | **Encoder Turn** | Moves the vertical selection (Index 0-63). |
| **Select Col** | **Fn 1 - Fn 4** | Switches between Pattern 0 to 3. |
| **Negate Value** | **Encoder Press** | Toggles sign of value or buffer. |
| **Commit Value** | **Shift + Encoder Press** | Writes buffer to pattern and advances length. |
| **Insert Digit** | **Step Keys 1-10** | Enables numeric entry (digits 0-9). |
| **Backspace** | **Page Left** | Deletes last digit from buffer. |
| **Delete Row** | **Shift + Page Left** | Deletes current row (shifts subsequent rows up). |
| **Insert Row** | **Page Right** | Duplicates current row (shifts subsequent rows down). |
| **Toggle Turtle**| **Shift + Page Right** | Toggles Turtle visibility on the grid. |
| **Set Length** | **Step Key 14** | Sets Pattern Length to current row + 1. |
| **Set Start** | **Step Key 15** | Sets Loop Start to current row. |
| **Set End** | **Step Key 16** | Sets Loop End to current row. |
